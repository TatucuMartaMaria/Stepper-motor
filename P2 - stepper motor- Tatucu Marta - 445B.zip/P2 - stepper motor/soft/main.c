/*********************************************
Project : Test software
**********************************************
Chip type: ATmega164A
Clock frequency: 20 MHz
Compilers:  CVAVR 2.x
*********************************************/

#include <mega164a.h>     //contine definitii, constante si functii predefinite care faciliteaza programarea controllerului Atmel ATmega1664A
#include <delay.h>         // contine f. pt introducerea unor intarzieri controlate
#include <string.h>          // char
#include <stdlib.h>         //ftoa()        stringuri + f. de conversie
#include <alcd.h>      // Alphanumeric LCD functions 
#include "defs.h"  


const int viteza=4;  //timpul dintre doi pasi (1pas = 1 activare de bobina)
int pozitie=0;
char afisare[20];     //buffer pentru afisare de tip char
int i;

void motor(int motor1, int motor2, int motor3, int motor4){
                if(motor1==1)m1=1;    //alimentez bobina ceruta
            else m1=0;                //altfel o tin oprita
               if(motor2==1)m2=1;
            else m2=0;
               if(motor3==1)m3=1;
            else m3=0;
               if(motor4==1)m4=1;
            else m4=0;
}

void motor_dreapta(){
 
    //  delay_us(20);
     motor(0,0,0,1); //activare pt una din bobine
     delay_ms(viteza);   //4ms
       motor(0,0,1,1);      //doua bobine
       delay_ms(viteza);
       motor(0,0,1,0);
      delay_ms(viteza);
       motor(0,1,1,0);
      delay_ms(viteza);
       motor(0,1,0,0);
     delay_ms(viteza); 
       motor(1,1,0,0);
     delay_ms(viteza);
       motor(1,0,0,0);
      delay_ms(viteza);
       motor(1,0,0,1);
      delay_ms(viteza);

  //    motor(0,0,0,0);
}

void motor_stanga(){
  
  //   delay_ms(20);
     motor(1,0,0,0);
     delay_ms(viteza);  
       motor(1,1,0,0);
     delay_ms(viteza);
       motor(0,1,0,0);
     delay_ms(viteza);
       motor(0,1,1,0);
     delay_ms(viteza); 
       motor(0,0,1,0);
     delay_ms(viteza);  
       motor(0,0,1,1);
     delay_ms(viteza);
       motor(0,0,0,1);
     delay_ms(viteza);
       motor(1,0,0,1);
     delay_ms(viteza); 
   //  motor(0,0,0,0);
}

void opreste_motor(){
  
      delay_ms(20);
     motor(0,0,0,0);
        }
        
void update_lcd(){
itoa(pozitie,afisare);           //converteste datele in CHAR pt afisare pe LCD          
lcd_gotoxy(0,0);   
lcd_puts("               ");        //sterge mesaj doar de pe primul rand
lcd_gotoxy(0,0);   
lcd_puts("Pozitie: ");        //afiseaza mesaj
for(i=0;i<strlen(afisare);i++){     //parcurge vectorul de afisare pe toata lungimea vectorului de afisare
                        
lcd_putchar(afisare[i]);    //afiseaza fiecare caracter pe rand 
}
}

/*
 * Timer 1 Output Compare A interrupt is used to blink LED
 */
interrupt [TIM1_COMPA] void timer1_compa_isr(void)   //timer1 configurat pt 1 secunda
{
LED1 = ~LED1; // invert LED  la 1 secunda  
update_lcd();

}                                  

/*
 * main function of program
 */
void main (void)
{               
   

	Init_initController();  // this must be the first "init" action/call!
	#asm("sei")             // enable global interrupts pt timer 1
	LED1 = 1;           	// initial state, will be changed by timer 1 
    
    // Alphanumeric LCD initialization
// Connections are specified in the
// Project|Configure|C Compiler|Libraries|Alphanumeric LCD menu:
// RS - PORTC Bit 0
// RD - PORTC Bit 1
// EN - PORTC Bit 2
// D4 - PORTC Bit 4
// D5 - PORTC Bit 5
// D6 - PORTC Bit 6
// D7 - PORTC Bit 7
// Characters/line: 16
lcd_init(16);     //initializare LCD cu 16 coloane   

	while(TRUE)
	{      
          wdogtrig();	        // call often else processor will reset
          

        if(SW1 == 0)        // pressed
        {
            delay_ms(30);   // debounce switch
            if(SW1 == 0)    
            {                // LED will blink slow or fast
                while(SW1==0)
                    wdogtrig();    // wait for release   
                    if(pozitie==360)pozitie=30;
                       else pozitie=pozitie+30;
                        update_lcd();
                         
                        lcd_gotoxy(0,1);   
                        lcd_puts("Dreapta");        //afiseaza mesaj
                         motor_dreapta();            
                         opreste_motor();   
                         delay_ms(500);   //timeout
                          lcd_gotoxy(0,1); 
                          lcd_puts("Stop   ");        //afiseaza mesaj
              }
              }  
              
              
                if(SW2 == 0)        // pressed
        {
            delay_ms(30);   // debounce switch
            if(SW2 == 0)    
            {                // LED will blink slow or fast
                while(SW2==0)
                    wdogtrig();    // wait for release  
                         if(pozitie==0)pozitie=360; //360==0
                        if(pozitie>=30) pozitie=pozitie-30;   
                       update_lcd();
                        
                        lcd_gotoxy(0,1);   
                        lcd_puts("Stanga ");        //afiseaza mesaj
                         motor_stanga();            
                         opreste_motor();   
                         delay_ms(500);   
                          lcd_gotoxy(0,1); 
                          lcd_puts("Stop   ");        //afiseaza mesaj
              }
              }    
		
                   
    } 

            
}// end main loop 


