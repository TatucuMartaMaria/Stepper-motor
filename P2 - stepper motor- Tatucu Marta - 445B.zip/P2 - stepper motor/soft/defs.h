/* definitions / defines file */
#define DEFS_H


#ifndef NULL
#define NULL  0
#endif
        
// logix ...
#define TRUE	1
#define FALSE	0 
#define DUMMY	0

#define wdogtrig()			#asm("wdr") // call often if Watchdog timer enabled


#define LED1 PORTD.6        // PORTx is used for output

#define m1 PORTC.0       // PORTx is used for output
#define m2 PORTC.1 
#define m3 PORTC.2 
#define m4 PORTC.3 
#define SW1 PIND.5 
#define SW2 PIND.4

#include "funct.h"

